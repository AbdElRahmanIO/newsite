<?php

/*
*-------------------------
*
* Front-End
*-------------------------
* Home Page >> Rebort Table
* Login Page
* Contact With programmer
*-------------------------
*
* Back-End
*-------------------------
* Projects
*   - Projects
*   - New Project
*   - Edit Project
* Resources
*   - Resources
*   - New Resource
*   - Edit Resource
* Project Managers
*   - Managers
*   - New Managers
*   - Edit Managers
*/

/*
**** Login Page ****
* (Email && Password)
*
**** Contact ****
* (name && email && subject && phone && text && capacha)
*
*
*
**** Projects ****
* (all Projects)
*
**** New Project ****
* (project name && project player && number of slides && static && basic && animation && app && start date && end date && resurces && Hours of evry resurce && Slides of evry resurce && project manager && Backgrounds && Thumbs)
*
**** Edit Project ****
* (Same New but add note sell for waves (comments))
*
*
*
**** Resources ****
* (all Resources)
*
**** New Resource ****
* (name && email && group(permission))
* 
**** Edit Resource ****
* (same new)
*
*
*
**** Managers ****
* (all Managers)
*
**** New Managers ****
* (name && email)
*
**** Edit Managers ****
* (same new)
*
*/


?>

